#!/usr/bin/python3 

import rospy
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
import actionlib
from actionlib_msgs.msg import * 
from geometry_msgs.msg import Pose, Point, Quaternion 

class goPosition(): 
    def __init__(self):
        
        self.goal_sent = False 

        rospy.on_shutdown(self.shutdown)

        self.move_base = actionlib.SimpleActionClient("move_base", MoveBaseAction) 
        rospy.loginfo("Wait for teh action server to come up") 

        self.move_base.wait_for_server(rospy.Duration(5)) 

    def goto(self, pos, quat): 

        self.goal_sent = True 
        goal = MoveBaseGoal() 
        goal.target_pose.header.frame_id = 'map' 
        goal.target_pose.header.stamp = rospy.Time.now() 
        goal.target_pose.pose = Pose(Point(pos['x'], pos['y'], 0.000), Quaternion(quat['r1'], quat['r2'], quat['r3'], quat['r4'])) 

        self.move_base.send_goal(goal) 

        success = self.move_base.wait_for_result(rospy.Duration(60)) 

        state = self.move_base.get_state() 
        result = False 

        if success and state == GoalStatus.SUCCEEDED: 
            result = True 
        else: 
            self.move_base.cancel_goal()
        
        self.goal_sent = False 
        return result 

    def shutdown(self): 
        if self.goal_sent: 
            self.move_base.cancel_goal() 
        rospy.loginfo("Stop") 
        rospy.sleep(1) 

if __name__ == '__main__': 
    try:
        rospy.init_node('nav_test', anonymous=False) 
        navigator = goPosition() 

        position = {'x': 0.074561707675457, 'y': -1.1254501342773438} 
        quaternion = {'r1': 0.000, 'r2': 0.000, 'r3': 0.000, 'r4': 1.000} 

        navigator.goto(position, quaternion)   

        position = {'x': 3.708785057067871, 'y': 0.17627458274364471} 
        quaternion = {'r1': 0.000, 'r2': 0.000, 'r3': 0.000, 'r4': 1.000} 

        navigator.goto(position, quaternion) 

        position = {'x': 0.7821202874183655, 'y': 1.2909561395645142} 
        quaternion = {'r1': 0.000, 'r2': 0.000, 'r3': 0.000, 'r4': 1.000} 

        navigator.goto(position, quaternion) 

        position = {'x': -0.3710528612136841, 'y': 2.6510672569274902} 
        quaternion = {'r1': 0.000, 'r2': 0.000, 'r3': 0.000, 'r4': 1.000} 

        navigator.goto(position, quaternion) 

        position = {'x': 0.040461864322423935, 'y': -0.00034476490691304207} 
        quaternion = {'r1': 0.000, 'r2': 0.000, 'r3': 0.000, 'r4': 1.000} 

        navigator.goto(position, quaternion)
        

        #if (success): 
        #    rospy.loginfo("We reached the position! ") 
        #else: 
        #    rospy.loginfo("We failed! ")

        rospy.sleep(1) 

    except rospy.ROSInterruptException: 
        rospy.loginfo("Ctrl-C caught. Quitting")