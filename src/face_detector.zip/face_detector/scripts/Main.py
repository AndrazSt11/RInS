#!/usr/bin/python3 

import sys
import rospy
import dlib
import cv2
import numpy as np
import tf2_geometry_msgs
import tf2_ros
import math
#import matplotlib.pyplot as plt
from sensor_msgs.msg import Image
from geometry_msgs.msg import PointStamped, Vector3, Pose
from cv_bridge import CvBridge, CvBridgeError
from visualization_msgs.msg import Marker, MarkerArray
from std_msgs.msg import ColorRGBA 
from face_detector.msg import FaceDetected, Detected

class Face:
    def __init__(self, x, y, z):
        # coordinates of a detected face
        self.x = x
        self.y = y
        self.z = z 

        # treshold for detection
        self.treshold = 0

        # Detection publisher
        self.detection_publisher = rospy.Publisher('detection', Detected); 

    def publish(self, x, y, z, exists, index):
        self.detection_publisher.publish(x, y, z, exists, index)

def faceDetection(data, args): 
    # checks if face was detected before and creates a marker if not
    detectedFace = Face(data.world_x, data.world_y, data.world_z) 

    faces = args 

    exists = False
    index = 0

    if (len(faces) == 0):
        # first detected face
        detectedFace.treshold += 1
        faces.append(detectedFace)
    else:
        count = 0
        # checks if face already exists
        for face in faces:
            distanceM = math.sqrt((face.x - detectedFace.x)**2 + (face.y - detectedFace.y)**2 + (face.z - detectedFace.z)**2) 

            if (distanceM < 1):
                exists = True
                index = count
                break
            count+=1  

        if (exists): 
            if (faces[index].treshold == 3):
                print("First one")
                exists = False

                # update treshold
                faces[index].treshold += 1

                # publish the changed cordinates
                detectedFace.publish(faces[index].x, faces[index].y, faces[index].z, exists, index) 
                print("Index je: ", index)
            elif (faces[index].treshold > 3):
                print("Already exist") 
                
                # if already exists update the coordinates
                avgX = (faces[index].x + detectedFace.x)/2 
                avgY = (faces[index].y + detectedFace.y)/2 
                avgZ = (faces[index].z + detectedFace.z)/2 

                # update the cordiates
                faces[index].x = avgX
                faces[index].y = avgY
                faces[index].z = avgZ

                # update treshold
                faces[index].treshold += 1

                print("Index je: ", index)

                # publish the changed cordinates
                detectedFace.publish(avgX, avgY, avgZ, exists, index)
            else: 
                # update treshold
                faces[index].treshold +=1 
                print("Index je: ", index)
                print("Dolzina: ", len(faces))
           
        else:
            # update treshold
            detectedFace.treshold += 1
            faces.append(detectedFace)


    #rospy.loginfo('worldX: %3.5f, worldY: %3.5f, worldZ: %3.5f', data.face_x, data.face_y, data.face_z)

def main(): 
    faces = []
    rospy.init_node('tester', anonymous=True)
    rospy.Subscriber('face_detection', FaceDetected, faceDetection, (faces)) 
    rospy.spin()

if __name__ == '__main__':
    main()
